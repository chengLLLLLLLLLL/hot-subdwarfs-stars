import pandas as pd
from scipy import interpolate
from scipy.interpolate import UnivariateSpline
import numpy as np
from scipy.optimize import curve_fit
from astropy.io import fits
import os


# data = pd.read_csv('obsid0.csv')
# data = data['obsid']
# for i in range(len(data)):
#     print(data[i])

# get=[]
# #
# for i in range(0,11):
#     print(i)
#     obsidpath = 'obsid'+str(i)+'.csv'
#     predictionpath = 'prediction' +str(i)+'.csv'
#     try:
#         obsid = pd.read_csv(obsidpath)
#
#         pred  = pd.read_csv(predictionpath)
#
#     except Exception:
#         continue
#
#     for k in range(len(obsid['obsid'])):
#         if(pred['y_pred'][k]==0):
#             get.append(obsid['obsid'][k])
#
#
# data = pd.DataFrame(get,columns=['yes'])
#
# data.to_csv('getObsid1.csv')

rootdir = 'E:\\fits\\'
list = os.listdir(rootdir)

num=0

for j in range(0, len(list)):

    path = os.path.join(rootdir, list[j])

    try:
        hdu = fits.open(path)
    except Exception:
        continue

    num = num + len(hdu[1].data)

print(num)

# hdu = fits.open('D:\\project\\hot\\hotsubwardf.fits')
#
# d = pd.read_csv('E:\\getObsid.csv')

# obsid = d['yes']
#
# n=0
#
# name=[]
# for i in range(len(hdu[1].data)):
#     name.append(hdu[1].data[i][0])
#
#
# for i in obsid:
#     if(name.count(i)):
#         n= n+1
# print(n)
#     # if(obsid.count(hdu[1].data[i][0])):
#     #     n=n+1
#
# print(n)
